# DivyKart Localhost Project

## Requirements
- Node.js 18+ recommended
- npm

## Run
1. Open Command Prompt in this folder.
2. Run:
   npm install
3. Run:
   npm start
4. Open:
   http://localhost:3000
5. Admin Panel:
   http://localhost:3000/admin

## Default local admin login
Username: admin
Password: admin123

You can change these before starting the server:
Windows CMD:
set ADMIN_USER=myadmin
set ADMIN_PASSWORD=mystrongpassword
npm start

PowerShell:
$env:ADMIN_USER="myadmin"
$env:ADMIN_PASSWORD="mystrongpassword"
npm start

## Persistence
All product changes are written to:
data/products.json

The public store always loads products from GET /api/products.
The Admin Panel uses:
- POST /api/products
- PUT /api/products/:id
- DELETE /api/products/:id

The server writes products atomically through a temporary file and rename operation.

## Important
This is designed for local development. The in-memory session token is intentionally simple for localhost. Do not expose this server directly to the public internet without replacing authentication with a production-grade identity/session system, HTTPS, rate limiting, CSRF protection and a proper database.
